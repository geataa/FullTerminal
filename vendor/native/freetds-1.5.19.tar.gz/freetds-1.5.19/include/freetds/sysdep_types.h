/* FreeTDS - Library of routines accessing Sybase and Microsoft databases
 * Copyright (C) 2021  Frediano Ziglio
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */

#ifndef _tdsguard_fhDKKbNsWAy7n0lapo2Voc_
#define _tdsguard_fhDKKbNsWAy7n0lapo2Voc_

#ifndef _tdsguard_gbdINUKdHN7rAOavGyKkWw_
#error Do not include directly, include <freetds/sysdep_private.h>
#endif

typedef   signed long  TDS_INTPTR;
typedef unsigned long TDS_UINTPTR;

#else
#error Do not include directly, include <freetds/sysdep_private.h>
#endif /* _tdsguard_fhDKKbNsWAy7n0lapo2Voc_ */
