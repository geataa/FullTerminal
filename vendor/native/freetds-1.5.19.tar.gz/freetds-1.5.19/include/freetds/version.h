/* FreeTDS - Library of routines accessing Sybase and Microsoft databases
 * Copyright (C) 1998-1999  Brian Bruns
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */

#ifndef _tdsguard_fWmaUBUxPCWj6BPyET5377_
#define _tdsguard_fWmaUBUxPCWj6BPyET5377_

/* $Id: c69b1270e9bbde50d3708cbfbf8921f8e849c928 $ */

#define TDS_VERSION_NO "freetds v1.5.19"

#define TDS_VERSION_MAJOR 1
#define TDS_VERSION_MINOR 5
#define TDS_VERSION_SUBVERSION 19
#define TDS_VERSION_BUILD_NUMBER 594

#endif
