var a01090 =
[
    [ "current_statement", "a01090.html#acaf05aab946ae9dec9e06dd230839675", null ],
    [ "cursor_support", "a01090.html#ae45d3601984f4773024a81394764d28d", null ],
    [ "stmt_list", "a01090.html#a4a9f3e8f1eba573df79a1ed300d8fc91", null ],
    [ "uad", "a01090.html#a93c0c73d7161aa0c8fd59016e66def9e", null ]
];