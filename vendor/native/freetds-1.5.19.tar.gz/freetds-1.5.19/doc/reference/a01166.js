var a01166 =
[
    [ "buffer", "a01166.html#a5ba4ad38fdcb68e7d0c7252be65a4ecc", null ],
    [ "write", "a01166.html#a8513fb41c8ba79f22e54266b87278415", null ]
];