var a01278 =
[
    [ "block_size", "a01278.html#aaad54522a6e04122eba4c37a200d3f20", null ],
    [ "charset", "a01278.html#a09756f0c4e0d588152c4dc3a8d019bcd", null ],
    [ "database", "a01278.html#ad05b5a83816aee8ff9858ddb1eb172b8", null ]
];