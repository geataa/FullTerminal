var a00594 =
[
    [ "Authentication", "a00585.html", "a00585" ],
    [ "Configuration", "a00586.html", "a00586" ],
    [ "Conversion", "a00587.html", "a00587" ],
    [ "Charset conversion", "a00588.html", "a00588" ],
    [ "Memory allocation", "a00589.html", "a00589" ],
    [ "Query", "a00590.html", "a00590" ],
    [ "Network functions", "a00591.html", "a00591" ],
    [ "Results processing", "a00592.html", "a00592" ],
    [ "Dynamic string functions", "a00593.html", "a00593" ]
];