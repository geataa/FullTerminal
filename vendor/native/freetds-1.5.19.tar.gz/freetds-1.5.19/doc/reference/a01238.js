var a01238 =
[
    [ "canonic", "a01238.html#aa9d3f1d6d994fcd5871ca41d7797ae95", null ],
    [ "name", "a01238.html#aa7152f00b01261e88db974cac1348c74", null ]
];