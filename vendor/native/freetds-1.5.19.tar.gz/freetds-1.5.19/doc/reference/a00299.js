var a00299 =
[
    [ "read_and_convert", "a00591.html#ga676c4dee6522815b16fdc8e448e43590", null ],
    [ "tds_dstr_get", "a00591.html#ga017c427e9599c031be5c555cb32abe2c", null ],
    [ "tds_get_byte", "a00591.html#ga0cb72d3f6943795c39db1fa692be0a58", null ],
    [ "tds_get_char_data", "a00591.html#ga8d214089b6e97fc0da5e0be09f216d73", null ],
    [ "tds_get_n", "a00591.html#gae777dd57e8d1bb40349d7d7d8434fddf", null ],
    [ "tds_get_string", "a00591.html#ga90f080e6e9448feac15dee1370d66802", null ],
    [ "tds_get_uint", "a00591.html#ga9ac121c269e203337a48c5bf8afc48c3", null ],
    [ "tds_get_uint8", "a00591.html#ga8ab6c87318eaf15ea17a9575763f7809", null ],
    [ "tds_get_usmallint", "a00591.html#gad38aa5b9547817854ccba1fcc7855861", null ],
    [ "tds_peek", "a00591.html#ga221e98a9c8be96ec6c8547891e1b53af", null ],
    [ "tds_unget_byte", "a00591.html#gad70d59fb317d098b0c9fd29dd77131a8", null ]
];