var a00650 =
[
    [ "login_timeout", "a00650.html#a2da93c0f3681f87f94ad169deb09dc64", null ],
    [ "query_timeout", "a00650.html#abf71abb24c7afea7dd7ef440048ea4c9", null ],
    [ "ref_count", "a00650.html#a812580afdfca53b6d54a7d09938c65c2", null ],
    [ "tds_ctx", "a00650.html#afb3fb2d591c0f75b9412f8ca77e2629d", null ],
    [ "tds_ctx_ref_count", "a00650.html#ad01d901acbc92e8c369e6a6c784d7446", null ]
];