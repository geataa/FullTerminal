var a01488 =
[
    [ "tds_sys_iconv_open", "a00588.html#ga900b0bce08c6bfc2e7c988f4b5970516", null ]
];