var a00593 =
[
    [ "tds_dstr", "a01374.html", null ],
    [ "DSTR_INITIALIZER", "a00593.html#ga581a03a4de6c926c57b4a75a11214df4", null ],
    [ "tds_dstr_empty", "a00593.html#ga42d67780bd4fd442915780d4815fc743", null ],
    [ "DSTR", "a00593.html#gafddddf5bd7ad223cadee3d3bdc899954", null ],
    [ "tds_dstr_alloc", "a00593.html#ga6aa14b8b717b51afcfb65bd55143689d", null ],
    [ "tds_dstr_buf", "a00593.html#gae092e53680d954bcf4f19334987d43c7", null ],
    [ "tds_dstr_copy", "a00593.html#gad96366d9fa93bfc283cef1299fbe97ab", null ],
    [ "tds_dstr_copyn", "a00593.html#ga656718f240d7403f986ae887d84a6ca1", null ],
    [ "tds_dstr_cstr", "a00593.html#gac536f0e4d77d3cff5702719362ec1766", null ],
    [ "tds_dstr_dup", "a00593.html#ga4e6d9fa6f9b9551a5a3390e10a5322e6", null ],
    [ "tds_dstr_free", "a00593.html#gaccd1c1c8ff938813578123963212388c", null ],
    [ "tds_dstr_init", "a00593.html#ga6c0aba5c6da921898768e7f6cf177ca7", null ],
    [ "tds_dstr_isempty", "a00593.html#ga197c6af67f2e7469d06c2aa055917b1e", null ],
    [ "tds_dstr_len", "a00593.html#ga396f139e4f886ac1b224a735138e73dd", null ],
    [ "tds_dstr_set", "a00593.html#gab78cc59b110df2817b00f9bed74c6ff1", null ],
    [ "tds_dstr_setlen", "a00593.html#ga0cd7863ba7c2d2da4a193234472a3d14", null ],
    [ "tds_dstr_zero", "a00593.html#ga339ba30216e2bd5bd076aa9dcd26f3c4", null ],
    [ "tds_str_empty", "a00593.html#ga676fd3c5c489584d09c89d66c7a0af2d", null ]
];