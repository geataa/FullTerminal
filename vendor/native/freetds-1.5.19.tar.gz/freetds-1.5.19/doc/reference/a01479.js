var a01479 =
[
    [ "tds_convert_stream", "a01479.html#a9d8eb43a81ff58ab423dce0ce95b9564", null ],
    [ "tds_copy_stream", "a01479.html#a50bc3749988d1c3c441044fc07ab44e4", null ],
    [ "tds_datain_stream_init", "a01479.html#abc3a77c8aa28842e7f28583cbabc1415", null ],
    [ "tds_datain_stream_read", "a01479.html#a04b537d889f7d4c9b9701eb81baf7efd", null ],
    [ "tds_dataout_stream_init", "a01479.html#aa038a9125979f8f0915dbd53cbf27e5a", null ],
    [ "tds_dataout_stream_write", "a01479.html#ae38a590ee08cf398e7adef536ac94538", null ],
    [ "tds_dynamic_stream_init", "a01479.html#a4f9e40da6941cb9407d0da5bc3030517", null ],
    [ "tds_dynamic_stream_write", "a01479.html#abaf688c85ea04a2392103d519a55d04e", null ],
    [ "tds_staticin_stream_init", "a01479.html#aa9e1e45f0305622dd6aed9f8fe158581", null ],
    [ "tds_staticin_stream_read", "a01479.html#a76b02f1fa5b79dc7e1ef2651a9afe3f7", null ],
    [ "tds_staticout_stream_init", "a01479.html#a9fe0d3799d2e3bde49b614c9d0c3785d", null ],
    [ "tds_staticout_stream_write", "a01479.html#a1d92ebe06f18378ac17ccfd20db05126", null ]
];