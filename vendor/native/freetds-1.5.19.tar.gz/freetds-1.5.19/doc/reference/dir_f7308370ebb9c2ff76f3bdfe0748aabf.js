var dir_f7308370ebb9c2ff76f3bdfe0748aabf =
[
    [ "bulk.c", "a00254.html", "a00254" ],
    [ "data.c", "a00263.html", "a00263" ],
    [ "iconv.c", "a01491.html", "a01491" ],
    [ "num_limits.h", "a00320_source.html", null ],
    [ "read.c", "a00299.html", "a00299" ],
    [ "sec_negotiate_gnutls.h", "a00311_source.html", null ],
    [ "sec_negotiate_openssl.h", "a00302_source.html", null ],
    [ "stream.c", "a01479.html", "a01479" ],
    [ "tds_types.h", "a00323_source.html", null ],
    [ "tds_willconvert.h", "a00317_source.html", null ],
    [ "token.c", "a00251.html", "a00251" ]
];