var searchData=
[
  ['a_20new_20type_0',['How to add a new type',['../a01447.html',1,'']]],
  ['add_20a_20new_20type_1',['How to add a new type',['../a01447.html',1,'']]],
  ['applications_20changes_2',['Applications changes',['../a01447.html#apps',1,'']]]
];
