var searchData=
[
  ['odbc_20changes_0',['ODBC changes',['../a01447.html#odbc',1,'']]]
];
