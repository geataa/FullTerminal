var searchData=
[
  ['changes_0',['changes',['../a01447.html#apps',1,'Applications changes'],['../a01447.html#ctlib',1,'CT-Library changes'],['../a01447.html#dblib',1,'DB-Library changes'],['../a01447.html#tds',1,'libTDS changes'],['../a01447.html#odbc',1,'ODBC changes']]],
  ['ct_20library_20changes_1',['CT-Library changes',['../a01447.html#ctlib',1,'']]]
];
