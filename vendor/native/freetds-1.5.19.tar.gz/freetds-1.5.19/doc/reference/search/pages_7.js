var searchData=
[
  ['library_20changes_0',['Library changes',['../a01447.html#ctlib',1,'CT-Library changes'],['../a01447.html#dblib',1,'DB-Library changes']]],
  ['libtds_20changes_1',['libTDS changes',['../a01447.html#tds',1,'']]],
  ['list_2',['List',['../a00573.html',1,'Bug List'],['../a00572.html',1,'Todo List']]]
];
