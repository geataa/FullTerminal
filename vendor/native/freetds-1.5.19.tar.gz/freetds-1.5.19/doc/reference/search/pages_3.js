var searchData=
[
  ['db_20library_20changes_0',['DB-Library changes',['../a01447.html#dblib',1,'']]]
];
