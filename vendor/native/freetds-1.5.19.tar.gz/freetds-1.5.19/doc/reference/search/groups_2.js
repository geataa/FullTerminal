var searchData=
[
  ['charset_20conversion_0',['Charset conversion',['../a00588.html',1,'']]],
  ['configuration_1',['Configuration',['../a00586.html',1,'']]],
  ['conversion_2',['Conversion',['../a00587.html',1,'']]],
  ['conversion_3',['Charset conversion',['../a00588.html',1,'']]],
  ['copy_20functions_4',['Bulk copy functions',['../a00577.html',1,'']]]
];
