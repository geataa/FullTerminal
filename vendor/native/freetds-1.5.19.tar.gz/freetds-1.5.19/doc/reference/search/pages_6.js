var searchData=
[
  ['introduction_0',['Introduction',['../a01447.html#intro',1,'Introduction'],['../index.html#intro_sec',1,'Introduction']]]
];
