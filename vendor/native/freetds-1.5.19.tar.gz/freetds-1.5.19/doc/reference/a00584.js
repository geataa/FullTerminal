var a00584 =
[
    [ "odbc_c_to_server_type", "a00584.html#ga3f0a413cea480a38d3d9b90c95515f6b", null ],
    [ "odbc_get_param_len", "a00584.html#ga35028e8de1d50dc51ccef1d645c55e2a", null ],
    [ "odbc_rdbms_version", "a00584.html#gae85ff7fb2002b5a7abc04fbee79e5525", null ],
    [ "odbc_set_concise_c_type", "a00584.html#ga128f6b09cde0af252370ba89cfa1fb78", null ],
    [ "odbc_set_concise_sql_type", "a00584.html#ga125574bd2de677438909612db80041ea", null ],
    [ "odbc_set_string_flag", "a00584.html#gadba4490bf3183799a70c9e2f44fab331", null ]
];