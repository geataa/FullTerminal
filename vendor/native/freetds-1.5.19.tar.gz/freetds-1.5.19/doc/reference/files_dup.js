var files_dup =
[
    [ "include", "dir_d44c64559bbebec7f509842c48db8b23.html", "dir_d44c64559bbebec7f509842c48db8b23" ],
    [ "src", "dir_68267d1309a1af8e8297ef4c3efbcdba.html", "dir_68267d1309a1af8e8297ef4c3efbcdba" ],
    [ "vms", "dir_88c98ec7a422f3972a0293d4e4a2e62e.html", "dir_88c98ec7a422f3972a0293d4e4a2e62e" ],
    [ "win32", "dir_b4f92dd377abba25bba37a57cb06d57a.html", "dir_b4f92dd377abba25bba37a57cb06d57a" ]
];