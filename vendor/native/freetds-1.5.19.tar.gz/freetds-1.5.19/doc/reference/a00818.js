var a00818 =
[
    [ "name", "a00818.html#aabc5f36785b65913edd51be1fd8ea1e3", null ],
    [ "next", "a00818.html#a3aaf5848cba17d39d5ea5bd180590bb3", null ]
];