var a00589 =
[
    [ "tds_alloc_compute_result", "a00589.html#ga93dcf17e404712a2c450a1b26cd5a0b7", null ],
    [ "tds_alloc_dynamic", "a00589.html#ga69559de43b47f4a9e2eecc7a56527444", null ],
    [ "tds_alloc_param_data", "a00589.html#ga4bbf9a6b6d514fc62ae67f548d54d78a", null ],
    [ "tds_alloc_param_result", "a00589.html#ga314c65c067570dc1ef3e58bbfc4eb763", null ],
    [ "tds_alloc_row", "a00589.html#ga1224fb9277112dc2ce12531d2b73b145", null ],
    [ "tds_detach_results", "a00589.html#ga1d60bf443e274797b1d1a9e7418ab962", null ],
    [ "tds_free_input_params", "a00589.html#gabdc5fee73b22345c02ab894e49ad7f95", null ],
    [ "tds_free_param_result", "a00589.html#ga66cd6e3c5089ced9415a8a0e258d205a", null ],
    [ "tds_get_dynid", "a00589.html#ga93503e64091b51add0801abebe22abf4", null ],
    [ "tds_init_login", "a00589.html#ga4f7b22f681e7160ac03dfe8d2ae8bd39", null ],
    [ "tds_realloc", "a00589.html#ga8645f5abc49db03d14b66f72b83a9a4c", null ],
    [ "tds_release_dynamic", "a00589.html#gabf2fdb0def5388508602ee7dd2f49506", null ]
];