var a01098 =
[
    [ "need_reprepare", "a01098.html#ac21b1c6a900bcb8dcb57bdeedcad8a72", null ],
    [ "next", "a01098.html#ad2152f527dcdd108165e7e03fe476b8f", null ],
    [ "param_count", "a01098.html#a36e6cb901103834b074bf5a00fe7afbe", null ],
    [ "param_num", "a01098.html#a9b8cb8cb0826323811192adbed126348", null ],
    [ "params", "a01098.html#aebe221315ae3dfd4850c399ad204ca4f", null ],
    [ "prepared_pos", "a01098.html#a45c0b5a3624186c84441d2e0f8a59c64", null ],
    [ "prev", "a01098.html#ad36ac281bcfcc5a6b6af0c1428b41d5f", null ],
    [ "query", "a01098.html#aaf4c8eb3163d2261ce6ce90118a70aec", null ],
    [ "row_count", "a01098.html#a8fd44f3c44ae4c83a1bdda0b73776ecd", null ],
    [ "row_status", "a01098.html#a41dd89b2dc41fe0e747580f6ea807063", null ],
    [ "tds", "a01098.html#ad357e33164f46fce2bc70267d71a1959", null ]
];