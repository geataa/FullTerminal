var a01282 =
[
    [ "defer_close", "a01282.html#a744986c76b9b09f29325a1e0664b0e9a", null ],
    [ "emulated", "a01282.html#a584f307fa2259557931105dbbb52ed2e", null ],
    [ "id", "a01282.html#a72332750aee80a0a94c92b35d7263d76", null ],
    [ "next", "a01282.html#adc93b94b6b4caf15dcf45297d928a8da", null ],
    [ "num_id", "a01282.html#af6fd2355838cce1689fb0e04724b7b6a", null ],
    [ "params", "a01282.html#adba427a655336d0b128cdec36544464b", null ],
    [ "query", "a01282.html#a1cee141e5f7045e691eec830cec1c158", null ],
    [ "ref_count", "a01282.html#a2798c66fb3c8637c7fb29c6d1efebfa4", null ],
    [ "res_info", "a01282.html#ac736e163c0d4cdbca980a861214d99e7", null ]
];