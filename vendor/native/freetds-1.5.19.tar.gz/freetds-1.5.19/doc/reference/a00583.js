var a00583 =
[
    [ "ODBC utility", "a00584.html", "a00584" ]
];