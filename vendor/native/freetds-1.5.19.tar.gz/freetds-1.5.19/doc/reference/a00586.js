var a00586 =
[
    [ "tdsvername_t", "a00770.html", null ],
    [ "parse_server_name_for_port", "a00586.html#ga0f9a22fb6744c5224a97ec3f83af4e15", null ],
    [ "search_interface_file", "a00586.html#ga56bdc4a30ba2d473f78954a42b00f2f7", null ],
    [ "tds8_adjust_login", "a00586.html#ga9622e7d6c98a77b1962647c5005d3731", null ],
    [ "tds_config_verstr", "a00586.html#ga05c73c963f4d8904869c739c556c58a2", null ],
    [ "tds_fix_login", "a00586.html#gacee4f06ba749b10ee9f2e5bb1c4a8910", null ],
    [ "tds_get_compiletime_settings", "a00586.html#ga0c00a50e074cec7fbb0a1de826a4a46b", null ],
    [ "tds_lookup_host", "a00586.html#ga3945f760ceb97e8854e18589d6f0d241", null ],
    [ "tds_lookup_port", "a00586.html#ga45281d1cb2ac649db65d80bb3ff06b66", null ],
    [ "tds_read_conf_file", "a00586.html#ga4799b423b5d982dbc8f31b7738255eef", null ],
    [ "tds_read_conf_section", "a00586.html#ga44fdbe16827097d947f900d96003de98", null ],
    [ "tds_read_config_info", "a00586.html#ga9ff2436ea56ddcdecf984acf46ce4b90", null ],
    [ "tds_read_interfaces", "a00586.html#ga66de78d379cad2ee3d6c26948ad6445f", null ],
    [ "tds_set_interfaces_file_loc", "a00586.html#ga57cea6e376d7c2d28b811a5b0053210c", null ]
];