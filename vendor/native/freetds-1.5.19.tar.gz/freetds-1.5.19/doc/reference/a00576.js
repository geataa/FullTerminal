var a00576 =
[
    [ "dbhasretstat", "a00576.html#ga7a5062dac92ccedc8459f6d4a530ffb7", null ],
    [ "dbnumrets", "a00576.html#gaff09873008411a0573f6d1a9e6c7cf4b", null ],
    [ "dbretdata", "a00576.html#ga61a32bcbc7b9d2522f6c85e91919f2c4", null ],
    [ "dbretlen", "a00576.html#gab705bf94be535e9d8fc4edc0f48c98b0", null ],
    [ "dbretname", "a00576.html#ga63dc384b5c0ee3086a171337e8c78317", null ],
    [ "dbretstatus", "a00576.html#ga2306039d73fbc7045f257b0e750c37b4", null ],
    [ "dbrettype", "a00576.html#gaa478c8b96923bca02d158d966172ec1b", null ],
    [ "dbrpcinit", "a00576.html#ga5b4374c13c7a83cd4345b0bfa3e787bd", null ],
    [ "dbrpcparam", "a00576.html#gaf6b6b0a641180a5c28382df39cd7d346", null ],
    [ "dbrpcsend", "a00576.html#gafa4dfd181be21e49c397f7daaa9cf96c", null ]
];