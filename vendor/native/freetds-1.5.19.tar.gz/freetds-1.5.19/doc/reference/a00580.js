var a00580 =
[
    [ "dbdatecmp", "a00580.html#ga129d2922d347121a6b312dd8e75ed6d2", null ],
    [ "dbmonthname", "a00580.html#ga689ca0aa93c2172e6e3db306b4e64f72", null ]
];