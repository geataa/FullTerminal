var a00646 =
[
    [ "resinfo", "a00646.html#ad49b82677ae277e5d5b0038f522da293", null ],
    [ "row", "a00646.html#a015599345b266045d8bd3fac731e4675", null ],
    [ "row_data", "a00646.html#a5a057d6bbecfac1a85a9fbcd09eaf3a0", null ],
    [ "sizes", "a00646.html#abe1aa9f8ea96dda1400654813e68130a", null ]
];