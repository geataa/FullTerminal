var a01310 =
[
    [ "bulk_query", "a01310.html#ac6ed7b8d3a4bd98a03f8ddb43b2e66c2", null ],
    [ "cur_cursor", "a01310.html#aa708effeb88270302ab5524f0c0366ac", null ],
    [ "cur_dyn", "a01310.html#afb404985164205ebdc9b0c18fabb47e2", null ],
    [ "current_results", "a01310.html#a4b77fb56b92b93e413fcbb8ba5633ce4", null ],
    [ "frozen_packets", "a01310.html#a0df77e05bf01c5e4c79a2b3c99b40666", null ],
    [ "has_status", "a01310.html#acd5eeef948380cd1b8abb132a417b2bf", null ],
    [ "in_buf", "a01310.html#a24c1995f6e8d0f9a5990998524b00b6b", null ],
    [ "in_cancel", "a01310.html#ae67d850cfbedf6b1e6b02111d4388d42", null ],
    [ "in_flag", "a01310.html#a765e007b69a2e188c989f05a689f6a11", null ],
    [ "in_len", "a01310.html#a0b6e65b9d00b3a4efbf78b2d866cca20", null ],
    [ "in_pos", "a01310.html#a9d1b4fc8e1e801fdc703ee7bb68d9838", null ],
    [ "in_row", "a01310.html#ab6a91be7f3b9966216e621c60e8151f2", null ],
    [ "login", "a01310.html#a00c22eeebbdb781ab7b9d5e8403e451e", null ],
    [ "out_buf", "a01310.html#ad6b5121e435d22d640a645b98833cb9d", null ],
    [ "out_buf_max", "a01310.html#ae6fc66be718f3211fac3b835557e330e", null ],
    [ "out_flag", "a01310.html#a9bb663ee7c71f56f1602cbfcd993018c", null ],
    [ "out_pos", "a01310.html#a426adbd80f29f477377e42e8f78d3ff0", null ],
    [ "ret_status", "a01310.html#a355e0b8c6219908747f82cd7482c6efb", null ],
    [ "rows_affected", "a01310.html#a803e29dabc76d35227f5de2488f29877", null ],
    [ "send_packet", "a01310.html#a1c7c38af79f5845b90f19aaf5f63ce18", null ]
];