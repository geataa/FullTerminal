var a01414 =
[
    [ "date", "a01414.html#afa93266cde7ab536615bca3d904aabed", null ],
    [ "offset", "a01414.html#a13159d738e1d0b582a3a731123feb5f3", null ],
    [ "time", "a01414.html#a6bb5dcd5b47813b71934546e0c60e035", null ]
];