var a01194 =
[
    [ "date", "a01194.html#a4697c11cf7da815856eb96bae4d57bac", null ],
    [ "offset", "a01194.html#a76f4cbcb3bc7c10b3616579ec7861f58", null ],
    [ "time", "a01194.html#afd6a58ec251f2c08a040917ba5a8cd3f", null ]
];