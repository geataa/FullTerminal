var a01250 =
[
    [ "bcp_prefix_len", "a01250.html#a07d747c0592ff37eb467ba14c4dcaeb2", null ],
    [ "char_conv", "a01250.html#ab3afb8272401bdb51064cdf910334159", null ],
    [ "column_cur_size", "a01250.html#ada14ba479a67762fc1bef78910ef4beb", null ],
    [ "column_prec", "a01250.html#a7ae346f8b1fdd364749825ca0863d166", null ],
    [ "column_scale", "a01250.html#ab73b012b3a9f08da8661dc230ec17d7f", null ],
    [ "column_size", "a01250.html#a2c2756c00a1099c82d4cfa4da2894672", null ],
    [ "column_type", "a01250.html#a7f08ecedc5835a4e81129c6b2b493947", null ],
    [ "column_varint_size", "a01250.html#a12914f03ee2f24fa3fe577060410770d", null ]
];