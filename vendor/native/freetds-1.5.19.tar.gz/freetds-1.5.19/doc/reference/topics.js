var topics =
[
    [ "The db-lib API", "a00574.html", "a00574" ],
    [ "ODBC API", "a00583.html", "a00583" ],
    [ "LibTDS API", "a00594.html", "a00594" ]
];