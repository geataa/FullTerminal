var a01326 =
[
    [ "pkt", "a01326.html#af900a7df4b6adae34d37233c3fb4cc99", null ],
    [ "pkt_pos", "a01326.html#a99de10b997fb8a417d1ba7123957a720", null ],
    [ "size_len", "a01326.html#ae857ba89e4d2b249da64e0e7287da962", null ],
    [ "tds", "a01326.html#a182ed346382edef2962aca11c7cabc22", null ]
];