var a01274 =
[
    [ "cursor_id", "a01274.html#a7b7d4cedf0cc7f890133f021d18af58c", null ],
    [ "cursor_name", "a01274.html#afd459125b5c4d4ccbf77a7d6ca8a4aaa", null ],
    [ "cursor_rows", "a01274.html#a7ec745adff5b2391e609e836c9f010cd", null ],
    [ "defer_close", "a01274.html#a411e76370c635dfabe9b5941cdd3180f", null ],
    [ "next", "a01274.html#a8743877d9147d83ef0ae64e04c8a46fb", null ],
    [ "options", "a01274.html#a1be9f69f84a6d83ce86380c33a2bf9f8", null ],
    [ "query", "a01274.html#aeec2a01af48693b8b22449f15725d502", null ],
    [ "ref_count", "a01274.html#a692ccceff71d836df0d084ec26123c2d", null ],
    [ "status", "a01274.html#ab5d6a587ac5780f001d383d4b874852f", null ],
    [ "type", "a01274.html#a889aafdde1d57c9be0585326022831f0", null ]
];