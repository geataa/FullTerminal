var a00926 =
[
    [ "login_timeout", "a00926.html#a1c6ce7f3fd8d21c59840bba9faa5d0c6", null ],
    [ "query_timeout", "a00926.html#a995ba257ef303066a726160decd7729c", null ],
    [ "use_large_identifiers", "a00926.html#a5133d4c302ef9aa6a2b4ec95628ce976", null ]
];