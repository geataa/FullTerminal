var a01306 =
[
    [ "cursors", "a01306.html#a42b972a1cd99c8f2f83b2cf5c635435a", null ],
    [ "dyns", "a01306.html#a7dc98cfe507c626073b6e76985a06a8a", null ],
    [ "env", "a01306.html#a17b3352a5f14239b2eecc4fc272bfe2a", null ],
    [ "ncharsize", "a01306.html#abd34063c79154fb12903e8af7101a2fb", null ],
    [ "pending_close", "a01306.html#a824fd854618d7d2005f2bec452247be7", null ],
    [ "product_version", "a01306.html#a7473cd879ba62019eb9d3bbb153832a1", null ],
    [ "s", "a01306.html#a4853be2466fd81c9463ac88f8da8b9c2", null ],
    [ "unicharsize", "a01306.html#a18f41c6fd5f75cea9d9db09a4cd3d937", null ]
];