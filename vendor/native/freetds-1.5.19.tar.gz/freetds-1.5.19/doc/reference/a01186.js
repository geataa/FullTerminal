var a01186 =
[
    [ "allocated", "a01186.html#a9f32de09fe01879aeed23e858f3cef79", null ],
    [ "buf", "a01186.html#a1b4967f395da537910ded1b392dd5d9b", null ],
    [ "size", "a01186.html#a9d221dd860f67d97daa71e107dce3470", null ]
];